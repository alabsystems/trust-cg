from pathlib import Path
import subprocess,os,json,time,hashlib
A=Path(__file__).resolve().parent;C=A/'source';e=json.loads((A/'ENVIRONMENT.json').read_text())
for k,v in os.environ.items():
 if k.startswith('BUILD_SLOT_')or k=='CARGO_BUILD_JOBS':e[k]=v
assert e.get('BUILD_SLOT_HELD')=='1'
def git(*v):return subprocess.check_output(['git',*v],cwd=C,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain');head=git('rev-parse','HEAD');cmd=['scripts/trust_cargo.sh','run','--locked','-p','trust-cg-verify','--example','proof_database_inventory','--','--format','tsv'];r={'head':head,'tree':git('rev-parse','HEAD^{tree}'),'lock_sha256':sha(C/'Cargo.lock'),'source_sha256':{p:sha(C/p)for p in ['crates/trust-cg-verify/src/proof_database.rs','crates/trust-cg-verify/src/checked_mul_i128_proofs.rs','crates/trust-cg-verify/examples/proof_database_inventory.rs']},'argv':cmd,'environment':e,'scope':'actualcurrentinventoryonly; treeidenticaltoactivecandidate4f686; no proofcampaign/nativetest/source/pinchange','started':time.time()};(A/'INPUTS.json').write_text(json.dumps(r,indent=2)+'\n')
with(A/'inventory.tsv').open('w')as out,(A/'build.log').open('w')as err:p=subprocess.run(cmd,cwd=C,env=e,stdout=out,stderr=err)
r.update(exit=p.returncode,seconds=time.time()-r['started'],source_unchanged=git('rev-parse','HEAD')==head and not git('status','--porcelain'),inventory_sha256=sha(A/'inventory.tsv'),log_sha256=sha(A/'build.log'));(A/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['exit','seconds','source_unchanged','inventory_sha256']}));raise SystemExit(p.returncode)
