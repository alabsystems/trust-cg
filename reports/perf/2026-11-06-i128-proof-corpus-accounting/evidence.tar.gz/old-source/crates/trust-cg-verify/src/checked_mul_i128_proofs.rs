// trust-cg-verify/checked_mul_i128_proofs.rs - i128/u128 checked-multiply idiom obligations
//
// Author: Andrew Yates <andrewyates.name@gmail.com>
// Copyright 2026 Andrew Yates | License: Apache-2.0

//! Proof obligations for the 128-bit checked-multiply idiom the adapter emits
//! for `Inst::Overflow { MulOverflow, I128 | U128 }` (ledger row L04-P10).
//!
//! The adapter (`build_u128_mul_overflow` / `build_i128_signed_mul_overflow`
//! in trust-cg-lower) does NOT compute a 256-bit product. It emits the low
//! 128-bit product and decides overflow with a guarded division identity:
//!
//! ```text
//! value = a * b                                    (Imul I128: MUL; UMULH; MADD; MADD)
//! u128:  flag = a != 0 && value /u (a == 0 ? 1 : a) != b
//! i128:  flag = (b != 0 && value /s g != a) || (a == MIN && b == -1)
//!        where g = (b == 0 || (a == MIN && b == -1)) ? 1 : b
//! ```
//!
//! The divisions are `__udivti3` / `__divti3` libcalls; the guards keep the
//! divisor non-zero and away from `MIN / -1`.
//!
//! Three obligations state the idiom, each with structurally distinct sides so
//! a wrong machine side can refute:
//!
//! * [`proof_imul_i128_low_product_chain`]: SOURCE is the 128-bit `bvmul` of
//!   the two operands; MACHINE is the limb chain ISel selects
//!   (`select_i128_mul`): `lo = a_lo * b_lo`, `hi = UMULH(a_lo, b_lo) +
//!   a_lo * b_hi + a_hi * b_lo` (mod 2^64), with UMULH stated as the high half
//!   of the exact 128-bit limb product. This supersedes the free-variable
//!   UMULH stand-in of `lowering_proof::proof_imul_i128_hi` (which stays
//!   registered for its existing bindings) now that the evaluator computes
//!   128-bit products.
//! * [`proof_checked_umul_i128_overflow_flag`]: SOURCE is trust-ir's checked
//!   multiply semantics — the exact 256-bit product does not fit in 128 bits,
//!   stated as "its high 128 bits are non-zero" and computed from 64-bit limb
//!   products with every intermediate at most 128 bits wide; MACHINE is the
//!   guarded `__udivti3` division identity above.
//! * [`proof_checked_smul_i128_overflow_flag`]: SOURCE is the exact signed
//!   product outside `[-2^127, 2^127 - 1]`, computed from operand magnitudes
//!   and the result sign; MACHINE is the guarded `__divti3` identity above.
//!
//! Evidence strength: every obligation carries four 64-bit limb inputs and is
//! discharged by the default evaluator — sampled `Statistical(N)` acceptance
//! plus the directed boundary battery of [`checked_mul_i128_credit`], which
//! also checks both sides against Rust's native `checked_mul`/`wrapping_mul`
//! at every battery point. That is regression evidence, not a formal proof;
//! the 128-bit `bvmul`/`bvudiv`/`bvsdiv` terms are outside the strict gate's
//! solver budget (the opt-in external-solver campaign has not been run over
//! them, like the 64-bit `CheckedSmul_I64`/`CheckedUmul_I64` rows).
//!
//! The coverage gate credits the `Umulh` row only when
//! [`checked_mul_i128_credit`] holds: every obligation is non-degenerate and
//! discharges, both sides agree with the native oracle on the battery, and
//! EVERY negative control ([`checked_mul_i128_controls`]) refutes — at its
//! directed witness, and under the sampling evaluator when it is
//! sampling-visible. A control that survives makes the hook refuse.
//!
//! What this does NOT establish — the named deferrals in
//! [`CHECKED_MUL_I128_DEFERRALS`]: the machine side is the LIR expansion the
//! adapter emits, stated over the ISel limb chain, not the Arm ARM semantics
//! of independently decoded captured encoder words (the `aarch64_value_decode_proofs`
//! form); the `__udivti3`/`__divti3` libcalls are assumed to implement
//! unsigned/signed 128-bit truncating division (no obligation covers the
//! runtime); and the per-compile function verifier still binds an emitted
//! UMULH to the 64-bit `CheckedUmul_I64` obligation, not to this chain.

use crate::lowering_proof::{
    MachineSideProvenance, ProofObligation, TransvalCheckKind, VerificationConfig,
    verify_by_evaluation_with_config,
};
use crate::smt::{EvalResult, SmtExpr};
use crate::verify::VerificationResult;
use std::collections::HashMap;

/// Which obligation of the family a control mutates.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CheckedMulI128Form {
    /// The low 128-bit product chain (`Imul I128`).
    LowProductChain,
    /// The unsigned overflow flag (`CheckedUmul` at U128).
    UnsignedFlag,
    /// The signed overflow flag (`CheckedSmul` at I128).
    SignedFlag,
}

impl CheckedMulI128Form {
    /// Every form, in registration order.
    pub const ALL: [Self; 3] = [Self::LowProductChain, Self::UnsignedFlag, Self::SignedFlag];

    /// The registered obligation of this form.
    pub fn obligation(self) -> ProofObligation {
        match self {
            Self::LowProductChain => proof_imul_i128_low_product_chain(),
            Self::UnsignedFlag => proof_checked_umul_i128_overflow_flag(),
            Self::SignedFlag => proof_checked_smul_i128_overflow_flag(),
        }
    }

    /// The lower-case name query the coverage gate resolves this form with;
    /// a unique substring of the registered name.
    pub const fn query(self) -> &'static str {
        match self {
            Self::LowProductChain => "imul_i128 low-product chain",
            Self::UnsignedFlag => "checkedumul_i128 overflow flag",
            Self::SignedFlag => "checkedsmul_i128 overflow flag",
        }
    }
}

/// What the family deliberately does not claim.
pub const CHECKED_MUL_I128_DEFERRALS: &[&str] = &[
    "decoded-word machine side: the MUL/UMULH/MADD chain and the CMP/CSEL/AND/ORR flag logic are \
     stated over the ISel limb chain, not decoded from captured encoder words \
     (aarch64_value_decode_proofs form); a wrong register choice encodes and decodes perfectly",
    "runtime division: __udivti3 / __divti3 are assumed to implement truncating unsigned / \
     signed 128-bit division on the guarded operands; no obligation covers the runtime library",
    "per-compile binding: FunctionVerifier::opcode_to_proof_query still binds an emitted UMULH \
     to CheckedUmul_I64; the i128 chain is credited at the coverage-gate row, not per instance",
];

const LIMB: u32 = 64;

fn bv1(cond: SmtExpr) -> SmtExpr {
    SmtExpr::ite(cond, SmtExpr::bv_const(1, 1), SmtExpr::bv_const(0, 1))
}

fn one1() -> SmtExpr {
    SmtExpr::bv_const(1, 1)
}

fn zero128() -> SmtExpr {
    SmtExpr::bv_const(0, LIMB).concat(SmtExpr::bv_const(0, LIMB))
}

fn one128() -> SmtExpr {
    SmtExpr::bv_const(0, LIMB).concat(SmtExpr::bv_const(1, LIMB))
}

/// `2^127` as a 128-bit constant (the `i128::MIN` pattern).
fn min128() -> SmtExpr {
    SmtExpr::bv_const(1 << 63, LIMB).concat(SmtExpr::bv_const(0, LIMB))
}

/// `2^127 - 1` as a 128-bit constant (`i128::MAX`).
fn max128() -> SmtExpr {
    SmtExpr::bv_const(i64::MAX as u64, LIMB).concat(SmtExpr::bv_const(u64::MAX, LIMB))
}

fn all_ones128() -> SmtExpr {
    SmtExpr::bv_const(u64::MAX, LIMB).concat(SmtExpr::bv_const(u64::MAX, LIMB))
}

/// The four limb inputs and their 128-bit compositions.
struct Limbs {
    a_lo: SmtExpr,
    a_hi: SmtExpr,
    b_lo: SmtExpr,
    b_hi: SmtExpr,
    a: SmtExpr,
    b: SmtExpr,
}

fn limbs() -> Limbs {
    let a_lo = SmtExpr::var("a_lo", LIMB);
    let a_hi = SmtExpr::var("a_hi", LIMB);
    let b_lo = SmtExpr::var("b_lo", LIMB);
    let b_hi = SmtExpr::var("b_hi", LIMB);
    let a = a_hi.clone().concat(a_lo.clone());
    let b = b_hi.clone().concat(b_lo.clone());
    Limbs {
        a_lo,
        a_hi,
        b_lo,
        b_hi,
        a,
        b,
    }
}

fn limb_inputs() -> Vec<(String, u32)> {
    vec![
        ("a_lo".to_string(), LIMB),
        ("a_hi".to_string(), LIMB),
        ("b_lo".to_string(), LIMB),
        ("b_hi".to_string(), LIMB),
    ]
}

/// Exact 128-bit unsigned product of two 64-bit limbs.
fn limb_product(x: SmtExpr, y: SmtExpr) -> SmtExpr {
    x.zero_ext(LIMB).bvmul(y.zero_ext(LIMB))
}

fn high64(x: SmtExpr) -> SmtExpr {
    x.extract(127, 64)
}

fn low64(x: SmtExpr) -> SmtExpr {
    x.extract(63, 0)
}

/// The high 128 bits of the exact 256-bit product `(a_hi:a_lo) * (b_hi:b_lo)`,
/// computed from the four 64x64 limb products with every intermediate at
/// most 128 bits wide (the evaluator's ceiling).
///
/// With `p00 = a_lo*b_lo`, `p01 = a_lo*b_hi`, `p10 = a_hi*b_lo`,
/// `p11 = a_hi*b_hi` (each exact in 128 bits):
///
/// ```text
/// mid1  = high64(p00) + p01          <= 2^128 - 2^64: never wraps
/// mid2  = mid1 + p10                 wraps at most once; carry = mid2 <u mid1
/// high  = high64(mid2) + p11 + (carry << 64)
/// ```
///
/// which is exact because the full product is
/// `low64(p00) + 2^64 * low64(mid2) + 2^128 * (high64(mid2) + carry*2^64 + p11)`
/// and the last factor is below `2^128`.
fn exact_high128_unsigned(a_lo: SmtExpr, a_hi: SmtExpr, b_lo: SmtExpr, b_hi: SmtExpr) -> SmtExpr {
    let p00 = limb_product(a_lo.clone(), b_lo.clone());
    let p01 = limb_product(a_lo, b_hi.clone());
    let p10 = limb_product(a_hi.clone(), b_lo);
    let p11 = limb_product(a_hi, b_hi);
    let mid1 = high64(p00).zero_ext(LIMB).bvadd(p01);
    let mid2 = mid1.clone().bvadd(p10);
    let carry = bv1(mid2.clone().bvult(mid1));
    let carry_term = carry
        .zero_ext(127)
        .bvshl(SmtExpr::bv_const(64, LIMB).zero_ext(LIMB));
    high64(mid2).zero_ext(LIMB).bvadd(p11).bvadd(carry_term)
}

/// SOURCE of the unsigned flag: trust-ir's `u128` checked multiply overflows
/// iff the exact product's high 128 bits are non-zero.
fn source_umul_i128_flag(l: &Limbs) -> SmtExpr {
    let high = exact_high128_unsigned(
        l.a_lo.clone(),
        l.a_hi.clone(),
        l.b_lo.clone(),
        l.b_hi.clone(),
    );
    bv1(high.eq_expr(zero128()).not_expr())
}

/// MACHINE of the unsigned flag: the guarded `__udivti3` division identity
/// `build_u128_mul_overflow` emits.
fn machine_umul_i128_flag(l: &Limbs) -> SmtExpr {
    let product = l.a.clone().bvmul(l.b.clone());
    let a_is_zero = l.a.clone().eq_expr(zero128());
    let safe_a = SmtExpr::ite(a_is_zero.clone(), one128(), l.a.clone());
    let q = product.bvudiv(safe_a);
    bv1(a_is_zero
        .not_expr()
        .and_expr(q.eq_expr(l.b.clone()).not_expr()))
}

/// SOURCE of the signed flag: trust-ir's `i128` checked multiply overflows iff
/// the exact signed product lies outside `[-2^127, 2^127 - 1]`. Stated over
/// operand magnitudes: with `m = |a| * |b|` exact (`high:low`, each 128 bits)
/// and the result negative iff exactly one operand is negative, overflow iff
/// `high != 0`, or `low > 2^127 - 1` for a non-negative result, or
/// `low > 2^127` for a negative one. `|i128::MIN| = 2^127` fits a `u128`.
fn source_smul_i128_flag(l: &Limbs) -> SmtExpr {
    let a_neg = l.a.clone().extract(127, 127).eq_expr(one1());
    let b_neg = l.b.clone().extract(127, 127).eq_expr(one1());
    let mag_a = SmtExpr::ite(a_neg.clone(), l.a.clone().bvneg(), l.a.clone());
    let mag_b = SmtExpr::ite(b_neg.clone(), l.b.clone().bvneg(), l.b.clone());
    let high = exact_high128_unsigned(
        low64(mag_a.clone()),
        high64(mag_a.clone()),
        low64(mag_b.clone()),
        high64(mag_b.clone()),
    );
    let low = mag_a.bvmul(mag_b);
    // Exactly one operand negative: a XOR b on the sign.
    let negative = a_neg.clone().eq_expr(b_neg).not_expr();
    let limit = SmtExpr::ite(negative, min128(), max128());
    bv1(high.eq_expr(zero128()).not_expr().or_expr(low.bvugt(limit)))
}

/// MACHINE of the signed flag: the guarded `__divti3` division identity
/// `build_i128_signed_mul_overflow` emits.
fn machine_smul_i128_flag(l: &Limbs) -> SmtExpr {
    let product = l.a.clone().bvmul(l.b.clone());
    let b_is_zero = l.b.clone().eq_expr(zero128());
    let a_is_min = l.a.clone().eq_expr(min128());
    let b_is_neg1 = l.b.clone().eq_expr(all_ones128());
    let min_neg1 = a_is_min.and_expr(b_is_neg1);
    let avoid_div = b_is_zero.clone().or_expr(min_neg1.clone());
    let safe_b = SmtExpr::ite(avoid_div, one128(), l.b.clone());
    let q = product.bvsdiv(safe_b);
    let div_ovf = b_is_zero
        .not_expr()
        .and_expr(q.eq_expr(l.a.clone()).not_expr());
    bv1(div_ovf.or_expr(min_neg1))
}

/// MACHINE of the low product: the `MUL; UMULH; MADD; MADD` limb chain
/// `select_i128_mul` emits, as the 128-bit pair `hi:lo`.
fn machine_imul_i128_chain(l: &Limbs) -> SmtExpr {
    let lo = l.a_lo.clone().bvmul(l.b_lo.clone());
    let umulh = high64(limb_product(l.a_lo.clone(), l.b_lo.clone()));
    // t1 = MADD a_lo, b_hi, t0  =>  t0 + a_lo * b_hi
    let t1 = umulh.bvadd(l.a_lo.clone().bvmul(l.b_hi.clone()));
    // hi = MADD a_hi, b_lo, t1  =>  t1 + a_hi * b_lo
    let hi = t1.bvadd(l.a_hi.clone().bvmul(l.b_lo.clone()));
    hi.concat(lo)
}

fn obligation(name: &str, source: SmtExpr, machine: SmtExpr) -> ProofObligation {
    ProofObligation {
        machine_side_provenance: MachineSideProvenance::StaticDb,
        name: name.to_string(),
        trust_ir_expr: source,
        aarch64_expr: machine,
        inputs: limb_inputs(),
        preconditions: vec![],
        fp_inputs: vec![],
        category: Some(TransvalCheckKind::InstructionLowering),
    }
}

/// `Imul I128`: the 128-bit product equals the `MUL; UMULH; MADD; MADD` limb
/// chain, with UMULH as the exact high half of the low-limb product.
pub fn proof_imul_i128_low_product_chain() -> ProofObligation {
    let l = limbs();
    obligation(
        "Imul_I128 low-product chain -> MUL+UMULH+MADD+MADD (128-bit product vs limb chain)",
        l.a.clone().bvmul(l.b.clone()),
        machine_imul_i128_chain(&l),
    )
}

/// `CheckedUmul` at U128: the overflow flag of the guarded `__udivti3`
/// division identity equals "the exact 256-bit product has a non-zero high
/// 128 bits".
pub fn proof_checked_umul_i128_overflow_flag() -> ProofObligation {
    let l = limbs();
    obligation(
        "CheckedUmul_I128 overflow flag -> guarded __udivti3 division identity (exact 256-bit \
         product high half)",
        source_umul_i128_flag(&l),
        machine_umul_i128_flag(&l),
    )
}

/// `CheckedSmul` at I128: the overflow flag of the guarded `__divti3`
/// division identity equals "the exact signed product is outside
/// `[-2^127, 2^127 - 1]`".
pub fn proof_checked_smul_i128_overflow_flag() -> ProofObligation {
    let l = limbs();
    obligation(
        "CheckedSmul_I128 overflow flag -> guarded __divti3 division identity (exact 256-bit \
         signed product)",
        source_smul_i128_flag(&l),
        machine_smul_i128_flag(&l),
    )
}

/// The three obligations of the family, in registration order.
pub fn all_checked_mul_i128_proofs() -> Vec<ProofObligation> {
    CheckedMulI128Form::ALL
        .iter()
        .map(|form| form.obligation())
        .collect()
}

/// A wrong machine side the family must refute.
#[derive(Clone)]
pub struct CheckedMulI128Control {
    /// The obligation whose machine side is replaced.
    pub form: CheckedMulI128Form,
    /// The miscompile this control stands for.
    pub label: &'static str,
    /// The wrong machine side.
    pub machine: fn() -> SmtExpr,
    /// `(a_lo, a_hi, b_lo, b_hi)` at which the wrong side diverges from the
    /// source side.
    pub witness: [u64; 4],
    /// Whether the default sampling evaluator (edge battery plus random
    /// limbs) must ALSO refute it. A control that diverges only on a sliver
    /// the sampler cannot reach is refuted by its directed witness alone.
    pub sampling_visible: bool,
}

impl std::fmt::Debug for CheckedMulI128Control {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("CheckedMulI128Control")
            .field("form", &self.form)
            .field("label", &self.label)
            .field("witness", &self.witness)
            .field("sampling_visible", &self.sampling_visible)
            .finish()
    }
}

fn control_chain_wrong_cross_limb() -> SmtExpr {
    // hi = UMULH + a_lo*b_hi + a_hi*b_HI: the second MADD reads the wrong limb.
    let l = limbs();
    let lo = l.a_lo.clone().bvmul(l.b_lo.clone());
    let umulh = high64(limb_product(l.a_lo.clone(), l.b_lo.clone()));
    let t1 = umulh.bvadd(l.a_lo.bvmul(l.b_hi.clone()));
    let hi = t1.bvadd(l.a_hi.bvmul(l.b_hi));
    hi.concat(lo)
}

fn control_chain_dropped_umulh() -> SmtExpr {
    // hi = a_lo*b_hi + a_hi*b_lo: the low-limb carry (UMULH) is dropped.
    let l = limbs();
    let lo = l.a_lo.clone().bvmul(l.b_lo.clone());
    let hi = l.a_lo.bvmul(l.b_hi).bvadd(l.a_hi.bvmul(l.b_lo));
    hi.concat(lo)
}

fn control_umul_guard_dropped() -> SmtExpr {
    // flag = value /u safe_a != b without the `a != 0` conjunct.
    let l = limbs();
    let product = l.a.clone().bvmul(l.b.clone());
    let safe_a = SmtExpr::ite(l.a.clone().eq_expr(zero128()), one128(), l.a);
    bv1(product.bvudiv(safe_a).eq_expr(l.b).not_expr())
}

fn control_umul_wrong_operand() -> SmtExpr {
    // flag = a != 0 && value /u safe_a != A: the quotient is compared with the
    // divisor's operand instead of the other factor.
    let l = limbs();
    let product = l.a.clone().bvmul(l.b);
    let a_is_zero = l.a.clone().eq_expr(zero128());
    let safe_a = SmtExpr::ite(a_is_zero.clone(), one128(), l.a.clone());
    bv1(a_is_zero
        .not_expr()
        .and_expr(product.bvudiv(safe_a).eq_expr(l.a).not_expr()))
}

fn control_umul_low_limb_idiom() -> SmtExpr {
    // flag = UMULH(a_lo, b_lo) != 0: the 64-bit idiom misapplied to the low
    // limbs, blind to the high limbs.
    let l = limbs();
    bv1(high64(limb_product(l.a_lo, l.b_lo))
        .eq_expr(SmtExpr::bv_const(0, LIMB))
        .not_expr())
}

fn control_smul_min_neg1_dropped() -> SmtExpr {
    // flag = b != 0 && value /s g != a with g guarding only b == 0.
    let l = limbs();
    let product = l.a.clone().bvmul(l.b.clone());
    let b_is_zero = l.b.clone().eq_expr(zero128());
    let safe_b = SmtExpr::ite(b_is_zero.clone(), one128(), l.b);
    bv1(b_is_zero
        .not_expr()
        .and_expr(product.bvsdiv(safe_b).eq_expr(l.a).not_expr()))
}

fn control_smul_unsigned_division() -> SmtExpr {
    // The signed identity with `__udivti3` where `__divti3` belongs.
    let l = limbs();
    let product = l.a.clone().bvmul(l.b.clone());
    let b_is_zero = l.b.clone().eq_expr(zero128());
    let a_is_min = l.a.clone().eq_expr(min128());
    let b_is_neg1 = l.b.clone().eq_expr(all_ones128());
    let min_neg1 = a_is_min.and_expr(b_is_neg1);
    let avoid_div = b_is_zero.clone().or_expr(min_neg1.clone());
    let safe_b = SmtExpr::ite(avoid_div, one128(), l.b);
    let div_ovf = b_is_zero
        .not_expr()
        .and_expr(product.bvudiv(safe_b).eq_expr(l.a).not_expr());
    bv1(div_ovf.or_expr(min_neg1))
}

fn control_smul_wrong_operand() -> SmtExpr {
    // The quotient is compared with b (the divisor's operand) instead of a.
    let l = limbs();
    let product = l.a.clone().bvmul(l.b.clone());
    let b_is_zero = l.b.clone().eq_expr(zero128());
    let a_is_min = l.a.eq_expr(min128());
    let b_is_neg1 = l.b.clone().eq_expr(all_ones128());
    let min_neg1 = a_is_min.and_expr(b_is_neg1);
    let avoid_div = b_is_zero.clone().or_expr(min_neg1.clone());
    let safe_b = SmtExpr::ite(avoid_div, one128(), l.b.clone());
    let div_ovf = b_is_zero
        .not_expr()
        .and_expr(product.bvsdiv(safe_b).eq_expr(l.b).not_expr());
    bv1(div_ovf.or_expr(min_neg1))
}

/// Limbs `(a_lo, a_hi, b_lo, b_hi)` of the pair `(a, b)`.
const fn limbs_of(a: u128, b: u128) -> [u64; 4] {
    [a as u64, (a >> 64) as u64, b as u64, (b >> 64) as u64]
}

/// The negative controls: characteristic miscompiles of the idiom, each with
/// the directed point at which it diverges from the source side.
pub fn checked_mul_i128_controls() -> Vec<CheckedMulI128Control> {
    use CheckedMulI128Form as F;
    vec![
        CheckedMulI128Control {
            form: F::LowProductChain,
            label: "second MADD multiplies a_hi by b_hi instead of b_lo",
            machine: control_chain_wrong_cross_limb,
            witness: limbs_of(1u128 << 64, 3),
            sampling_visible: true,
        },
        CheckedMulI128Control {
            form: F::LowProductChain,
            label: "UMULH carry of the low-limb product dropped",
            machine: control_chain_dropped_umulh,
            witness: limbs_of(1u128 << 63, 4),
            sampling_visible: true,
        },
        CheckedMulI128Control {
            form: F::UnsignedFlag,
            label: "a != 0 guard dropped (0 * b flagged for every b != 1)",
            machine: control_umul_guard_dropped,
            witness: limbs_of(0, 2),
            sampling_visible: false,
        },
        CheckedMulI128Control {
            form: F::UnsignedFlag,
            label: "quotient compared with the divisor's operand a instead of b",
            machine: control_umul_wrong_operand,
            witness: limbs_of(2, 3),
            sampling_visible: false,
        },
        CheckedMulI128Control {
            form: F::UnsignedFlag,
            label: "64-bit UMULH idiom misapplied to the low limbs (high limbs ignored)",
            machine: control_umul_low_limb_idiom,
            witness: limbs_of(1u128 << 64, 1u128 << 64),
            sampling_visible: true,
        },
        CheckedMulI128Control {
            form: F::SignedFlag,
            label: "MIN * -1 term dropped",
            machine: control_smul_min_neg1_dropped,
            witness: limbs_of(i128::MIN as u128, -1i128 as u128),
            sampling_visible: false,
        },
        CheckedMulI128Control {
            form: F::SignedFlag,
            label: "__udivti3 where __divti3 belongs",
            machine: control_smul_unsigned_division,
            witness: limbs_of(-2i128 as u128, 3),
            sampling_visible: false,
        },
        CheckedMulI128Control {
            form: F::SignedFlag,
            label: "quotient compared with b instead of a",
            machine: control_smul_wrong_operand,
            witness: limbs_of(2, 3),
            sampling_visible: false,
        },
    ]
}

/// Directed unsigned boundary pairs: the product and flag edges a division
/// identity either recovers or does not.
pub const UMUL_I128_BATTERY: &[(u128, u128)] = &[
    (0, u128::MAX),
    (u128::MAX, 0),
    (1, u128::MAX),
    (u128::MAX, 1),
    (u128::MAX, 2),
    (2, u128::MAX),
    (1 << 127, 2),
    (1 << 127, 1),
    ((1 << 127) - 1, 2),
    (1 << 64, 1 << 64),
    ((1 << 64) - 1, (1 << 64) - 1),
    (1 << 64, (1 << 64) - 1),
    ((1 << 64) + 1, (1 << 64) - 1),
    ((1 << 64) + 1, (1 << 64) + 1),
    (1 << 65, 1 << 64),
    (1 << 63, 1 << 63),
    (1 << 63, 1 << 65),
    (1 << 63, 1 << 64),
    (7, 0),
    (5, 3),
    (u128::MAX, u128::MAX),
    (u128::MAX / 3, 3),
    (u128::MAX / 3 + 1, 3),
];

/// Directed signed boundary pairs.
pub const SMUL_I128_BATTERY: &[(i128, i128)] = &[
    (i128::MIN, -1),
    (-1, i128::MIN),
    (i128::MIN, 1),
    (i128::MIN, 0),
    (i128::MAX, 1),
    (i128::MAX, 2),
    (i128::MAX, -1),
    (i128::MAX, -2),
    (i128::MIN, 2),
    (i128::MIN / 2, 2),
    (i128::MIN / 2, -2),
    (1 << 64, 1 << 64),
    ((1 << 64) - 1, (1 << 64) - 1),
    (1 << 63, 1 << 63),
    (1 << 63, 1 << 64),
    (-(1 << 63), 1 << 64),
    (1 << 126, 2),
    (1 << 126, -2),
    (-(1 << 126), -2),
    (-(1 << 126), 2),
    (0, i128::MAX),
    (0, i128::MIN),
    (5, 3),
    (-5, 3),
    (5, -3),
    (-5, -3),
    (i128::MAX, i128::MAX),
    (i128::MIN, i128::MIN),
];

fn env_of(limbs: [u64; 4]) -> HashMap<String, u64> {
    HashMap::from([
        ("a_lo".to_string(), limbs[0]),
        ("a_hi".to_string(), limbs[1]),
        ("b_lo".to_string(), limbs[2]),
        ("b_hi".to_string(), limbs[3]),
    ])
}

/// What the coverage gate learns from a successful credit.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CheckedMulI128Credit {
    /// Obligations that discharged under the evaluator.
    pub obligations: usize,
    /// Directed boundary points at which both sides matched the native oracle.
    pub battery_points: usize,
    /// Negative controls refuted.
    pub controls_refuted: usize,
}

/// The production credit: the registered obligations, the registered control
/// battery and the default evaluator configuration. Cached per process — the
/// audit of the AArch64 inventory would otherwise re-run the sampling sweep
/// for every row.
pub fn checked_mul_i128_credit() -> Result<CheckedMulI128Credit, String> {
    static CREDIT: std::sync::OnceLock<Result<CheckedMulI128Credit, String>> =
        std::sync::OnceLock::new();
    CREDIT
        .get_or_init(|| {
            checked_mul_i128_credit_with(
                &all_checked_mul_i128_proofs(),
                &checked_mul_i128_controls(),
                &VerificationConfig::default(),
            )
        })
        .clone()
}

/// [`checked_mul_i128_credit`] over injected obligations and controls, so a
/// test can hand the hook a degenerate obligation or a surviving control and
/// watch it refuse.
///
/// Refuses unless: every form has exactly one obligation, which is
/// non-degenerate and evaluates `Valid`; at every battery point both sides of
/// the flag obligations equal Rust's native `checked_mul` verdict and both
/// sides of the chain obligation equal `wrapping_mul`; and every control is
/// non-degenerate, diverges from its form's source side at its witness (a
/// point where the real obligation agrees), and — when sampling-visible — is
/// refuted by the evaluator as well.
pub fn checked_mul_i128_credit_with(
    obligations: &[ProofObligation],
    controls: &[CheckedMulI128Control],
    config: &VerificationConfig,
) -> Result<CheckedMulI128Credit, String> {
    let mut by_form: Vec<(CheckedMulI128Form, &ProofObligation)> = Vec::new();
    for form in CheckedMulI128Form::ALL {
        let query = form.query();
        let matching: Vec<&ProofObligation> = obligations
            .iter()
            .filter(|o| o.name.to_lowercase().contains(query))
            .collect();
        let [only] = matching[..] else {
            return Err(format!(
                "{form:?}: expected exactly one obligation matching {query:?}, found {}",
                matching.len()
            ));
        };
        if !only.is_genuinely_proven() {
            return Err(format!(
                "{form:?}: obligation {:?} is degenerate (source == machine)",
                only.name
            ));
        }
        match verify_by_evaluation_with_config(only, config) {
            VerificationResult::Valid => {}
            other => {
                return Err(format!(
                    "{form:?}: obligation {:?} did not discharge: {other:?}",
                    only.name
                ));
            }
        }
        by_form.push((form, only));
    }
    let obligation_of = |form: CheckedMulI128Form| -> Result<&ProofObligation, String> {
        by_form
            .iter()
            .find(|(f, _)| *f == form)
            .map(|(_, o)| *o)
            .ok_or_else(|| format!("{form:?}: no resolved obligation"))
    };

    // Directed battery against the native oracle.
    let mut battery_points = 0;
    let chain = obligation_of(CheckedMulI128Form::LowProductChain)?;
    let umul = obligation_of(CheckedMulI128Form::UnsignedFlag)?;
    for &(a, b) in UMUL_I128_BATTERY {
        let env = env_of(limbs_of(a, b));
        let want_flag = EvalResult::Bv(u64::from(a.checked_mul(b).is_none()));
        for (side, expr) in [
            ("source", &umul.trust_ir_expr),
            ("machine", &umul.aarch64_expr),
        ] {
            let got = expr.eval(&env);
            if got != want_flag {
                return Err(format!(
                    "unsigned flag {side} side disagrees with native u128::checked_mul at \
                     ({a:#x}, {b:#x}): got {got:?}, want {want_flag:?}"
                ));
            }
        }
        let want_product = EvalResult::Bv128(a.wrapping_mul(b));
        for (side, expr) in [
            ("source", &chain.trust_ir_expr),
            ("machine", &chain.aarch64_expr),
        ] {
            let got = expr.eval(&env);
            if got != want_product {
                return Err(format!(
                    "low-product chain {side} side disagrees with native wrapping_mul at \
                     ({a:#x}, {b:#x}): got {got:?}, want {want_product:?}"
                ));
            }
        }
        battery_points += 1;
    }
    let smul = obligation_of(CheckedMulI128Form::SignedFlag)?;
    for &(a, b) in SMUL_I128_BATTERY {
        let env = env_of(limbs_of(a as u128, b as u128));
        let want_flag = EvalResult::Bv(u64::from(a.checked_mul(b).is_none()));
        for (side, expr) in [
            ("source", &smul.trust_ir_expr),
            ("machine", &smul.aarch64_expr),
        ] {
            let got = expr.eval(&env);
            if got != want_flag {
                return Err(format!(
                    "signed flag {side} side disagrees with native i128::checked_mul at \
                     ({a}, {b}): got {got:?}, want {want_flag:?}"
                ));
            }
        }
        let want_product = EvalResult::Bv128(a.wrapping_mul(b) as u128);
        for (side, expr) in [
            ("source", &chain.trust_ir_expr),
            ("machine", &chain.aarch64_expr),
        ] {
            let got = expr.eval(&env);
            if got != want_product {
                return Err(format!(
                    "low-product chain {side} side disagrees with native wrapping_mul at \
                     ({a}, {b}): got {got:?}, want {want_product:?}"
                ));
            }
        }
        battery_points += 1;
    }

    // Every control must refute.
    let mut controls_refuted = 0;
    for form in CheckedMulI128Form::ALL {
        if !controls.iter().any(|c| c.form == form) {
            return Err(format!("{form:?} has no negative control"));
        }
    }
    for control in controls {
        let real = obligation_of(control.form)?;
        let wrong = (control.machine)();
        if wrong == real.trust_ir_expr {
            return Err(format!(
                "control {:?} ({:?}) is the source side itself and cannot refute",
                control.label, control.form
            ));
        }
        let env = env_of(control.witness);
        let source_at = real.trust_ir_expr.eval(&env);
        let real_at = real.aarch64_expr.eval(&env);
        if source_at != real_at {
            return Err(format!(
                "control {:?} ({:?}): the real obligation itself disagrees at the witness \
                 {:?} ({source_at:?} vs {real_at:?})",
                control.label, control.form, control.witness
            ));
        }
        let wrong_at = wrong.eval(&env);
        if wrong_at == source_at {
            return Err(format!(
                "control {:?} ({:?}) SURVIVES at its witness {:?}: both sides give {source_at:?}",
                control.label, control.form, control.witness
            ));
        }
        if control.sampling_visible {
            let mutated = ProofObligation {
                name: format!("NEGATIVE: {} ({:?})", control.label, control.form),
                aarch64_expr: wrong,
                ..real.clone()
            };
            match verify_by_evaluation_with_config(&mutated, config) {
                VerificationResult::Invalid { .. } => {}
                other => {
                    return Err(format!(
                        "control {:?} ({:?}) SURVIVES the sampling evaluator: {other:?}",
                        control.label, control.form
                    ));
                }
            }
        }
        controls_refuted += 1;
    }

    Ok(CheckedMulI128Credit {
        obligations: by_form.len(),
        battery_points,
        controls_refuted,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ay_bridge::{AYConfig, AYResult, verify_with_ay_cli};
    use crate::lowering_proof::verify_by_evaluation;

    #[test]
    fn family_has_three_non_degenerate_obligations_that_discharge() {
        let proofs = all_checked_mul_i128_proofs();
        assert_eq!(proofs.len(), 3);
        for proof in &proofs {
            assert!(
                proof.is_genuinely_proven(),
                "DEGENERATE (X==X) obligation {:?}",
                proof.name
            );
            assert_eq!(proof.inputs, limb_inputs());
            assert!(
                matches!(verify_by_evaluation(proof), VerificationResult::Valid),
                "{} did not pass the default evaluator",
                proof.name
            );
        }
        let names: std::collections::HashSet<&str> =
            proofs.iter().map(|p| p.name.as_str()).collect();
        assert_eq!(names.len(), 3, "names must be unique");
        for form in CheckedMulI128Form::ALL {
            let hits = proofs
                .iter()
                .filter(|p| p.name.to_lowercase().contains(form.query()))
                .count();
            assert_eq!(hits, 1, "{form:?}: query {:?} must be unique", form.query());
        }
    }

    #[test]
    fn credit_holds_with_the_registered_battery_and_controls() {
        let credit = checked_mul_i128_credit().unwrap_or_else(|e| panic!("credit refused: {e}"));
        assert_eq!(
            credit,
            CheckedMulI128Credit {
                obligations: 3,
                battery_points: UMUL_I128_BATTERY.len() + SMUL_I128_BATTERY.len(),
                controls_refuted: checked_mul_i128_controls().len(),
            }
        );
        assert_eq!(checked_mul_i128_controls().len(), 8);
    }

    #[test]
    fn credit_refuses_a_surviving_control() {
        let mut controls = checked_mul_i128_controls();
        controls.push(CheckedMulI128Control {
            form: CheckedMulI128Form::UnsignedFlag,
            label: "identity mutation must survive",
            machine: || machine_umul_i128_flag(&limbs()),
            witness: limbs_of(5, 3),
            sampling_visible: false,
        });
        let err = checked_mul_i128_credit_with(
            &all_checked_mul_i128_proofs(),
            &controls,
            &VerificationConfig::default(),
        )
        .expect_err("a surviving control must refuse the credit");
        assert!(err.contains("SURVIVES"), "{err}");
    }

    #[test]
    fn credit_refuses_a_degenerate_or_missing_obligation() {
        let mut proofs = all_checked_mul_i128_proofs();
        let l = limbs();
        proofs[1].aarch64_expr = source_umul_i128_flag(&l);
        let err = checked_mul_i128_credit_with(
            &proofs,
            &checked_mul_i128_controls(),
            &VerificationConfig::default(),
        )
        .expect_err("a degenerate obligation must refuse the credit");
        assert!(err.contains("degenerate"), "{err}");

        let missing: Vec<ProofObligation> =
            all_checked_mul_i128_proofs().into_iter().take(2).collect();
        let err = checked_mul_i128_credit_with(
            &missing,
            &checked_mul_i128_controls(),
            &VerificationConfig::default(),
        )
        .expect_err("a missing form must refuse the credit");
        assert!(err.contains("expected exactly one obligation"), "{err}");
    }

    #[test]
    fn credit_refuses_a_wrong_flag_that_the_battery_sees() {
        // A machine side that flags every product overflows at (5, 3), where
        // the native oracle says no overflow.
        let mut proofs = all_checked_mul_i128_proofs();
        proofs[1].aarch64_expr = bv1(SmtExpr::bool_const(true));
        let err = checked_mul_i128_credit_with(
            &proofs,
            &checked_mul_i128_controls(),
            &VerificationConfig::default(),
        )
        .expect_err("a wrong flag must refuse the credit");
        assert!(
            err.contains("did not discharge") || err.contains("native u128::checked_mul"),
            "{err}"
        );
    }

    /// The exact-high-half reconstruction is what the source sides rest on:
    /// check it against native 256-bit arithmetic simulated with `u128`
    /// halves at points that exercise every carry path.
    #[test]
    fn exact_high128_matches_native_wide_products() {
        let l = limbs();
        let high = exact_high128_unsigned(l.a_lo, l.a_hi, l.b_lo, l.b_hi);
        let points: &[(u128, u128)] = &[
            (u128::MAX, u128::MAX),
            (u128::MAX, 2),
            (1 << 64, 1 << 64),
            ((1 << 64) - 1, (1 << 64) - 1),
            ((1 << 64) + 1, u128::MAX),
            (u128::MAX - 1, u128::MAX - 1),
            (1 << 127, 2),
            (1 << 127, 1 << 127),
            (
                0xdead_beef_cafe_f00d_0123_4567_89ab_cdef,
                0xfedc_ba98_7654_3210_0fed_cba9_8765_4321,
            ),
            (0, u128::MAX),
        ];
        for &(a, b) in points {
            // Native: split into 64-bit limbs and accumulate in u128 with
            // explicit carries (a different arrangement from the SMT side).
            let (a0, a1) = (a as u64 as u128, a >> 64);
            let (b0, b1) = (b as u64 as u128, b >> 64);
            let p00 = a0 * b0;
            let p01 = a0 * b1;
            let p10 = a1 * b0;
            let p11 = a1 * b1;
            let (m1, c1) = (p00 >> 64).overflowing_add(p01);
            let (m2, c2) = m1.overflowing_add(p10);
            let carries = u128::from(c1) + u128::from(c2);
            let want = (m2 >> 64) + p11 + (carries << 64);
            let got = high.eval(&env_of(limbs_of(a, b)));
            assert_eq!(got, EvalResult::Bv128(want), "high128 at ({a:#x}, {b:#x})");
        }
    }

    /// Every deferral is named, and the family's documentation of what it
    /// does not claim is non-empty.
    #[test]
    fn deferrals_are_named() {
        assert_eq!(CHECKED_MUL_I128_DEFERRALS.len(), 3);
        assert!(
            CHECKED_MUL_I128_DEFERRALS
                .iter()
                .any(|d| d.contains("decoded-word"))
        );
    }

    /// Formal attempt: the family's 128-bit `bvmul`/division terms are beyond
    /// the strict gate's solver budget like the 64-bit mul rows, so a Timeout,
    /// or an Unknown the strict gate files as capacity, is tolerated. A
    /// CounterExample is a refutation, and an Error, or an Unknown the strict
    /// gate files as a SOUNDNESS failure (a working checker's rejection of AY's
    /// proof, AY's own self-check rejection, a trusted proof step, an internal
    /// error), is a verdict on a proof, not capacity: each fails the test, the
    /// same discipline as the 64-bit rows in `checked_overflow_proofs`.
    #[test]
    fn formal_attempt_never_refutes() {
        if !crate::ay_bridge::z3_available() {
            crate::formal_gap::skip_test(
                "formal_attempt_never_refutes",
                crate::formal_gap::NO_PROOF_AUTHORITY,
            );
            return;
        }
        let config = AYConfig::default().with_timeout(10_000);
        for proof in all_checked_mul_i128_proofs() {
            let result = verify_with_ay_cli(&proof, &config);
            match result {
                AYResult::Unknown(ref reason)
                    if crate::proof_gate::unknown_is_hard_failure(reason) =>
                {
                    panic!(
                        "{} returned {result}; the strict proof gate files this as a soundness \
                         failure, not capacity",
                        proof.name
                    )
                }
                AYResult::Verified
                | AYResult::SolverUnsat
                | AYResult::Timeout
                | AYResult::Unknown(_) => {}
                AYResult::CounterExample(cx) => {
                    panic!("SOUNDNESS: {} REFUTED by {cx:?}", proof.name)
                }
                AYResult::Error(e) => panic!("{} solver error: {e}", proof.name),
            }
        }
    }
}
