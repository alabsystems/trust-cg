from pathlib import Path
import json,os,subprocess,time,hashlib
A=Path(__file__).resolve().parent;C=A/'cg';O=A/'fixture-29ebb-final-controls';e=json.loads((A/'ENVIRONMENT.json').read_text());e['PATH']=str(Path(e['TRUST_TARGO']).parent)+':'+str(A/'attested-system-bin')+':/bin:/sbin';e.pop('PYTHON',None)
commands=[['python3','-I','-B','scripts/tests/test_release_harness_syntax_gate.py','ReleaseTrustCompilerListTests'],['scripts/check_fmt.sh'],['python3','-I','-B','scripts/check_documentation.py','--check']]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['crates/trust-cg-codegen/fixture_toolchain.rs','scripts/release_trust_compilers.txt','scripts/run_public_release_checks.sh','docs/decision-record.md'];before={p:sha(C/p)for p in files};r={'commands':commands,'source':before,'environment':e,'started':time.time(),'results':[]}
(O/'INPUTS.json').write_text(json.dumps(r,indent=2)+'\n')
for i,cmd in enumerate(commands):
 with(O/f'{i}.log').open('w')as f:p=subprocess.run(cmd,cwd=C,env=e,stdout=f,stderr=subprocess.STDOUT)
 r['results'].append({'command':cmd,'exit':p.returncode,'log_sha256':sha(O/f'{i}.log')})
 if p.returncode:break
r.update(exit=p.returncode,seconds=time.time()-r['started'],source_unchanged=before=={p:sha(C/p)for p in files});(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['results']));raise SystemExit(p.returncode)
