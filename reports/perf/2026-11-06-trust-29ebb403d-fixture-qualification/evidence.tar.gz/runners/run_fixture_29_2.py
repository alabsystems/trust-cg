from pathlib import Path
import json,subprocess,os,time,hashlib
A=Path(__file__).resolve().parent;C=A/'cg';O=A/'fixture-29ebb-qualification-2';O.mkdir(exist_ok=False);e=json.loads((A/'ENVIRONMENT.json').read_text());e['CARGO_TARGET_DIR']=str(A/'train-target.noindex');e['PATH']=str(Path(e['TRUST_TARGO']).parent)+':'+str(A/'attested-system-bin')+':/bin:/sbin';e.pop('PYTHON',None)
for k,v in os.environ.items():
 if k.startswith('BUILD_SLOT_')or k=='CARGO_BUILD_JOBS':e[k]=v
assert e.get('BUILD_SLOT_HELD')=='1'
def git(*a):return subprocess.check_output(['git',*a],cwd=C,text=True).strip()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=git('rev-parse','HEAD');patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=C);(O/'SOURCE.patch').write_bytes(patch);paths=git('diff','HEAD','--name-only').splitlines();assert set(paths)=={'crates/trust-cg-codegen/fixture_toolchain.rs','scripts/release_trust_compilers.txt'}
files={p:sha(C/p)for p in git('ls-files','crates/trust-cg-codegen/fixture_toolchain.rs','scripts/release_trust_compilers.txt','crates/trust-cg-codegen/tests/e2e_*.rs','scripts/run_public_release_codegen_tests.sh','scripts/release_gate_summary.py').splitlines()}
r={'head':head,'patch_sha256':sha(O/'SOURCE.patch'),'files':files,'environment':e,'compiler':subprocess.check_output([str(Path(e['TRUST_TARGO']).parent/'trustc'),'-vV'],env=e,text=True),'targo':subprocess.check_output([e['TRUST_TARGO'],'--unverified','--version'],env=e,text=True),'scope':'documented unpublished exact compiler/host candidate, genuine maintained complete11-target/118-case independent-process qualification; no whitelist is published without actual success; no fixture/oracle/test/policy/grade changes','started':time.time()};(O/'INPUTS.json').write_text(json.dumps(r,indent=2)+'\n')
cmd=[str(C/'scripts/run_public_release_codegen_tests.sh'),'--qualify-kernel-layout-fixtures','--proof-gate=require'];r['argv']=cmd
with(O/'native.log').open('w')as f:p=subprocess.run(cmd,cwd=C,env=e,stdout=f,stderr=subprocess.STDOUT)
r.update(exit=p.returncode,seconds=time.time()-r['started'],source_unchanged=head==git('rev-parse','HEAD')and patch==subprocess.check_output(['git','diff','HEAD','--binary'],cwd=C)and all(sha(C/p)==h for p,h in files.items()),log_sha256=sha(O/'native.log'));(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(r['exit'],r['seconds']);assert r['source_unchanged'];raise SystemExit(p.returncode)
