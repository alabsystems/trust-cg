import Trust.Cert.CheckedMulI128UnsignedControls
open Trust.Cert.CheckedMulI128Unsigned
open Trust.Cert.CheckedMulI128Unsigned.Controls
example : (if Not (originalSourceBV 18446744073709551615 0 18446744073709551615 1 = 0) then (1 : BitVec 1) else 0) =
    (if omittedArm 2 18446744073709551615 0 18446744073709551615 1 then (1 : BitVec 1) else 0) :=
  original_unsigned_limb_check_flag 18446744073709551615 0 18446744073709551615 1
