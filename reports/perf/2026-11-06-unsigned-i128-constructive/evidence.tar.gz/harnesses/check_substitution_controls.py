import hashlib
import json
import os
from pathlib import Path
import subprocess

area = Path(__file__).resolve().parent
old = area / "qualification-final-1"
result = json.loads((old / "RESULT.json").read_text())
out = area / "qualification-negative-2"
out.mkdir()
rows = []
for tool in result["tools"]:
    version = tool["version"]
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(("LEAN_", "ELAN_", "LAKE_"))}
    env.update({"LEAN_PATH": str(old / version / "lib"),
                "LEAN_SYSROOT": tool["root"], "LEAN_ABORT_ON_PANIC": "1"})
    for omitted in range(4):
        text = (old / version / ("Mutant" + str(omitted) + ".lean")).read_text()
        start = text.index("example : (if ") + len("example : (if ")
        end = text.index(" != 0 then", start)
        text = text[:start] + "Not (" + text[start:end] + " = 0)" + text[end + len(" != 0"):]
        path = out / (version + "-Mutant" + str(omitted) + ".lean")
        path.write_text(text)
        cmd = [str(Path(tool["root"]) / "bin/lean"), str(path)]
        p = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           timeout=30)
        log = out / (path.stem + ".log")
        log.write_bytes(p.stdout)
        passed = (p.returncode != 0 and b"error: Type mismatch" in p.stdout
                  and b"original_unsigned_limb_check_flag" in p.stdout
                  and b"omittedArm" in p.stdout and b"unknown module" not in p.stdout)
        row = {"argv": cmd, "exit": p.returncode, "expected_rejection": passed,
               "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
               "log_sha256": hashlib.sha256(p.stdout).hexdigest()}
        rows.append(row)
        (out / "ROWS.json").write_text(json.dumps(rows, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        if not passed:
            raise RuntimeError("Missing concrete original-proof type mismatch")
(out / "RESULT.json").write_text(json.dumps({"status": "PASS", "rows": rows,
    "positive_source_hashes": result["source_hashes"], "scope":
    "Same exact Prop source side; four deleted-arm expected goals each reject the original proof in both worlds. All accepted positive/theorem source unchanged."}, indent=2) + "\n")
