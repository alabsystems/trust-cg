import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

AREA = Path(__file__).resolve().parent
SOURCE = AREA / "source"
ROOT = SOURCE / "formal/lean"
NAME = "Trust.Cert.CheckedMulI128Unsigned"
FILES = [ROOT / "Trust/Cert/CheckedMulI128Unsigned.lean",
         ROOT / "Trust/Cert/CheckedMulI128UnsignedControls.lean"]
TOOLS = {
    "4.31.0": Path("$HOME/trust-cg-release-prereqs-20261105-nfu/lean-4.31.0-darwin_aarch64"),
    "4.30.0-rc2": Path("$HOME/trust-source-fixes-main-landing-20261027/merge-7e1dbd/aligned-inputs/elan-home/toolchains/leanprover--lean4---v4.30.0-rc2"),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


out = AREA / "qualification-final-1"
out.mkdir()
before = {str(p.relative_to(SOURCE)): p.read_bytes() for p in FILES}
for p, data in before.items():
    target = out / "source" / p
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

rows = []


def run(label, argv, env, expected=0):
    start = time.monotonic()
    process = subprocess.run(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, timeout=90)
    log = out / (label + ".log")
    log.write_bytes(process.stdout)
    row = {"label": label, "argv": argv, "returncode": process.returncode,
           "expected": expected, "seconds": time.monotonic() - start,
           "log": str(log), "log_sha256": sha(process.stdout)}
    row["pass"] = (process.returncode == 0 if expected == 0 else process.returncode != 0)
    rows.append(row)
    (out / "ROWS.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    if not row["pass"]:
        raise RuntimeError("Unexpected proof/check outcome: " + label)
    return process.stdout


tool_rows = []
for version, tool in TOOLS.items():
    lib = out / version / "lib"
    module_dir = lib / "Trust/Cert"
    module_dir.mkdir(parents=True)
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(("LEAN_", "ELAN_", "LAKE_"))}
    env.update({"LEAN_PATH": str(lib), "LEAN_SYSROOT": str(tool),
                "LEAN_ABORT_ON_PANIC": "1"})
    lean = str(tool / "bin/lean")
    checker = str(tool / "bin/leanchecker")
    identity = {"version": version, "root": str(tool),
                "lean_sha256": sha(Path(lean).read_bytes()),
                "leanchecker_sha256": sha(Path(checker).read_bytes())}
    identity["actual_version"] = run(version + "-version", [lean, "--version"], env).decode().strip()
    identity["githash"] = run(version + "-githash", [lean, "--githash"], env).decode().strip()
    tool_rows.append(identity)
    for source in FILES:
        run(version + "-" + source.stem,
            [lean, "--root=" + str(ROOT), "-o", str(module_dir / (source.stem + ".olean")),
             str(source)], env)
    run(version + "-local-kernel-replay", [checker, "--verbose", NAME], env)
    for omitted, values in enumerate([
        [0, 2, 9223372036854775808, 0],
        [9223372036854775808, 0, 0, 2],
        [18446744073709551615, 0, 18446744073709551615, 1],
        [0, 1, 0, 1],
    ]):
        arguments = " ".join(map(str, values))
        mutant = out / version / ("Mutant" + str(omitted) + ".lean")
        mutant.write_text("import " + NAME + "Controls\n"
            "open Trust.Cert.CheckedMulI128Unsigned\n"
            "open Trust.Cert.CheckedMulI128Unsigned.Controls\n"
            "example : (if originalSourceBV " + arguments + " != 0 then (1 : BitVec 1) else 0) =\n"
            "    (if omittedArm " + str(omitted) + " " + arguments + " then (1 : BitVec 1) else 0) :=\n"
            "  original_unsigned_limb_check_flag " + arguments + "\n")
        run(version + "-hostile-proof-substitution-" + str(omitted),
            [lean, str(mutant)], env, expected="nonzero")

result = {
    "status": "PASS", "rows": rows, "tools": tool_rows,
    "source_base": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE).decode().strip(),
    "source_hashes": {p: sha(data) for p, data in before.items()},
    "source_unchanged": all((SOURCE / p).read_bytes() == data for p, data in before.items()),
    "rust_original_source_sha256": sha((SOURCE / "crates/trust-cg-verify/src/checked_mul_i128_proofs.rs").read_bytes()),
    "scope": "Genuine Lean elaboration and local proof replay in two distinct worlds; no Clean replay, AY verdict, SMT/CIC binding, proof inventory or production grade change.",
}
result["artifacts"] = [{"path": str(p.relative_to(out)), "sha256": sha(p.read_bytes()),
                        "size": p.stat().st_size}
                       for p in sorted(out.rglob("*")) if p.is_file()]
(out / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "source_unchanged": result["source_unchanged"],
                  "rows": len(rows), "result": str(out / "RESULT.json")}), flush=True)
