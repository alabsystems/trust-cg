import subprocess,time,json,hashlib,pathlib,sys
area=pathlib.Path(__file__).parent
source=area/'source/formal/lean/Trust/Cert/CheckedMulI128Unsigned.lean'
tool=pathlib.Path('$HOME/trust-cg-release-prereqs-20261105-nfu/lean-4.31.0-darwin_aarch64/bin/lean')
out=area/sys.argv[1];out.mkdir()
before=source.read_bytes()
(out/'CheckedMulI128Unsigned.lean').write_bytes(before)
cmd=[str(tool),'-o',str(out/'CheckedMulI128Unsigned.olean'),str(source)]
t=time.monotonic()
p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,cwd=source.parents[3])
(out/'lean.log').write_bytes(p.stdout)
result={'command':cmd,'source_sha256':hashlib.sha256(before).hexdigest(),'source_unchanged':source.read_bytes()==before,'tool_sha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'returncode':p.returncode,'seconds':time.monotonic()-t}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(p.stdout.decode(errors='replace'));print(json.dumps(result))
sys.exit(p.returncode)
