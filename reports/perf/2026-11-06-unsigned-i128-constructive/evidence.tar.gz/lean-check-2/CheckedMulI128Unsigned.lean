/-
  Constructive arithmetic for the exact unsigned division-free i128 flag.
  This module does not register a Rust proof verdict or change the AY query.
-/
import Std.Tactic

set_option autoImplicit false
namespace Trust.Cert.CheckedMulI128Unsigned

private abbrev limbBase : Nat := 18446744073709551616

/-- An exact two-limb product has no wrapped or fabricated high payload. -/
theorem limb_product_bound (x y : Nat) (hx : x < limbBase) (hy : y < limbBase) :
    x * y < limbBase * limbBase := by
  exact Nat.mul_lt_mul'' hx hy

/-- The zero-product premise used by the free-product attempt is proved, not assumed. -/
theorem limb_product_zero (x y : Nat) :
    x * y = 0 ↔ x = 0 ∨ y = 0 := Nat.mul_eq_zero

/-- Adding a proper limb to a two-limb value overflows one limb exactly when
    its high limb is nonzero or the wrapped low limb is less than the addend. -/
theorem cross_add_overflow (h p : Nat) (hh : h < limbBase) :
    limbBase ≤ h + p ↔
      p / limbBase ≠ 0 ∨ (h + p % limbBase) % limbBase < p % limbBase := by
  have hd := Nat.mod_add_div p limbBase
  have hm := Nat.mod_lt p (by decide : 0 < limbBase)
  have hs := Nat.mod_add_div (h + p % limbBase) limbBase
  have hsm := Nat.mod_lt (h + p % limbBase) (by decide : 0 < limbBase)
  simp only [limbBase] at *
  omega

end Trust.Cert.CheckedMulI128Unsigned
