import Trust.Cert.CheckedMulI128UnsignedControls
open Trust.Cert.CheckedMulI128Unsigned
open Trust.Cert.CheckedMulI128Unsigned.Controls
example : (if originalSourceBV 0 1 0 1 != 0 then (1 : BitVec 1) else 0) =
    (if omittedArm 3 0 1 0 1 then (1 : BitVec 1) else 0) :=
  original_unsigned_limb_check_flag 0 1 0 1
