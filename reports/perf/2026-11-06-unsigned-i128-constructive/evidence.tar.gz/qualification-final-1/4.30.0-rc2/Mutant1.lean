import Trust.Cert.CheckedMulI128UnsignedControls
open Trust.Cert.CheckedMulI128Unsigned
open Trust.Cert.CheckedMulI128Unsigned.Controls
example : (if originalSourceBV 9223372036854775808 0 0 2 != 0 then (1 : BitVec 1) else 0) =
    (if omittedArm 1 9223372036854775808 0 0 2 then (1 : BitVec 1) else 0) :=
  original_unsigned_limb_check_flag 9223372036854775808 0 0 2
