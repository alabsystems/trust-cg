import Trust.Cert.CheckedMulI128SignedControls
open Trust.Cert.CheckedMulI128Signed
open Trust.Cert.CheckedMulI128Signed.Controls
example : (if originalSourceSignedFlag 2 0 0 13835058055282163712 then (1 : BitVec 1) else 0) =
    (if mutantFlag .rawCore 2 0 0 13835058055282163712 then (1 : BitVec 1) else 0) :=
  original_signed_limb_check_flag 2 0 0 13835058055282163712
