import Trust.Cert.CheckedMulI128SignedControls
open Trust.Cert.CheckedMulI128Signed
open Trust.Cert.CheckedMulI128Signed.Controls
example : (if originalSourceSignedFlag 0 9223372036854775808 18446744073709551615 18446744073709551615 then (1 : BitVec 1) else 0) =
    (if mutantFlag .orSign 0 9223372036854775808 18446744073709551615 18446744073709551615 then (1 : BitVec 1) else 0) :=
  original_signed_limb_check_flag 0 9223372036854775808 18446744073709551615 18446744073709551615
