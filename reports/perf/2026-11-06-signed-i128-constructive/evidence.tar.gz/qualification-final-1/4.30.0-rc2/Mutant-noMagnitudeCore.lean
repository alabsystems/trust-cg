import Trust.Cert.CheckedMulI128SignedControls
open Trust.Cert.CheckedMulI128Signed
open Trust.Cert.CheckedMulI128Signed.Controls
example : (if originalSourceSignedFlag 3 0 6148914691236517206 6148914691236517205 then (1 : BitVec 1) else 0) =
    (if mutantFlag .noMagnitudeCore 3 0 6148914691236517206 6148914691236517205 then (1 : BitVec 1) else 0) :=
  original_signed_limb_check_flag 3 0 6148914691236517206 6148914691236517205
