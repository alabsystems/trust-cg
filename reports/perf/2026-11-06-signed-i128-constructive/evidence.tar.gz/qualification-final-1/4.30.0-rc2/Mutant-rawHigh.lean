import Trust.Cert.CheckedMulI128SignedControls
open Trust.Cert.CheckedMulI128Signed
open Trust.Cert.CheckedMulI128Signed.Controls
example : (if originalSourceSignedFlag 14304268710930555488 18446744073709551615 15199015601233879320 4 then (1 : BitVec 1) else 0) =
    (if mutantFlag .rawHigh 14304268710930555488 18446744073709551615 15199015601233879320 4 then (1 : BitVec 1) else 0) :=
  original_signed_limb_check_flag 14304268710930555488 18446744073709551615 15199015601233879320 4
