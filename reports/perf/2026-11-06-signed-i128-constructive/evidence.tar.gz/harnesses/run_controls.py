import hashlib,json,os,subprocess,sys,time
from pathlib import Path
area=Path(__file__).resolve().parent
root=area/'source/formal/lean'
source=root/'Trust/Cert/CheckedMulI128SignedControls.lean'
tool=Path('$HOME/trust-cg-release-prereqs-20261105-nfu/lean-4.31.0-darwin_aarch64')
out=area/sys.argv[1];out.mkdir()
lib=out/'lib/Trust/Cert';lib.mkdir(parents=True)
base=area/'lean-check-7/lib/Trust/Cert'
for artifact in base.iterdir():
 if artifact.is_file():(lib/artifact.name).write_bytes(artifact.read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith(('LEAN_','ELAN_','LAKE_'))}
env.update({'LEAN_PATH':str(out/'lib'),'LEAN_SYSROOT':str(tool),'PATH':str(tool/'bin')+':'+env.get('PATH',''),'LEAN_ABORT_ON_PANIC':'1'})
before=source.read_bytes();(out/source.name).write_bytes(before)
cmd=[str(tool/'bin/lean'),'--root='+str(root),'-o',str(lib/'CheckedMulI128SignedControls.olean'),str(source)]
t=time.monotonic();p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
(out/'lean.log').write_bytes(p.stdout)
r={'argv':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(before).hexdigest(),'source_unchanged':source.read_bytes()==before}
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(p.stdout.decode(errors='replace'));print(json.dumps(r));sys.exit(p.returncode)
