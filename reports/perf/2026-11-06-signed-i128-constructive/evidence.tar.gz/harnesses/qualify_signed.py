import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

AREA = Path(__file__).resolve().parent
SOURCE = AREA / "source"
ROOT = SOURCE / "formal/lean"
NAME = "Trust.Cert.CheckedMulI128Signed"
FILES = [ROOT / "Trust/Cert/CheckedMulI128Signed.lean",
         ROOT / "Trust/Cert/CheckedMulI128SignedControls.lean"]
UNSIGNED_AREA = Path("$HOME/trust-unsigned-limb-proof-20261106-t97xc2pd")
UNSIGNED = json.loads((UNSIGNED_AREA / "qualification-final-1/RESULT.json").read_text())
TOOLS = {row["version"]: row for row in UNSIGNED["tools"]}
CONTROLS = [
    ("noZeroGuard", [0, 9223372036854775808, 0, 0]),
    ("noSignCheck", [18446744073709551615, 18446744073709551615, 0, 9223372036854775808]),
    ("noMagnitudeCore", [3, 0, 6148914691236517206, 6148914691236517205]),
    ("orSign", [0, 9223372036854775808, 18446744073709551615, 18446744073709551615]),
    ("rawHigh", [14304268710930555488, 18446744073709551615, 15199015601233879320, 4]),
    ("rawCore", [2, 0, 0, 13835058055282163712]),
    ("unsignedDispatch", [18446744073709551615, 18446744073709551615, 2, 0]),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


out = AREA / "qualification-final-1"
out.mkdir()
before = {str(p.relative_to(SOURCE)): p.read_bytes() for p in FILES}
for p, data in before.items():
    target = out / "source" / p
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

rows = []


def run(label, argv, env, reject=False):
    start = time.monotonic()
    p = subprocess.run(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=120)
    log = out / (label + ".log")
    log.write_bytes(p.stdout)
    passed = p.returncode == 0
    if reject:
        passed = (p.returncode != 0 and b"error: Type mismatch" in p.stdout
                  and b"original_signed_limb_check_flag" in p.stdout
                  and b"mutantFlag" in p.stdout and b"unknown module" not in p.stdout)
    row = {"label": label, "argv": argv, "returncode": p.returncode,
           "expected": "proof-type-mismatch" if reject else 0,
           "seconds": time.monotonic() - start, "log": str(log),
           "log_sha256": sha(p.stdout), "pass": passed}
    rows.append(row)
    (out / "ROWS.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    if not passed:
        raise RuntimeError("Unexpected outcome: " + label)
    return p.stdout


tool_rows = []
imports = []
for version, identity in TOOLS.items():
    tool = Path(identity["root"])
    lean = str(tool / "bin/lean")
    checker = str(tool / "bin/leanchecker")
    assert sha(Path(lean).read_bytes()) == identity["lean_sha256"]
    assert sha(Path(checker).read_bytes()) == identity["leanchecker_sha256"]
    lib = out / version / "lib"
    module_dir = lib / "Trust/Cert"
    module_dir.mkdir(parents=True)
    provider = UNSIGNED_AREA / "qualification-final-1" / version / "lib/Trust/Cert"
    for p in provider.glob("CheckedMulI128Unsigned.*"):
        data = p.read_bytes()
        target = module_dir / p.name
        target.write_bytes(data)
        imports.append({"provider": str(p), "path": str(target), "sha256": sha(data),
                        "world": version, "source_sha256": UNSIGNED["source_hashes"][
                            "formal/lean/Trust/Cert/CheckedMulI128Unsigned.lean"]})
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(("LEAN_", "ELAN_", "LAKE_"))}
    env.update({"LEAN_PATH": str(lib), "LEAN_SYSROOT": str(tool),
                "PATH": str(tool / "bin") + ":" + env.get("PATH", ""),
                "LEAN_ABORT_ON_PANIC": "1"})
    version_text = run(version + "-version", [lean, "--version"], env).decode().strip()
    githash = run(version + "-githash", [lean, "--githash"], env).decode().strip()
    assert version_text == identity["actual_version"] and githash == identity["githash"]
    tool_rows.append(identity)
    for source in FILES:
        log = run(version + "-" + source.stem,
            [lean, "--root=" + str(ROOT), "-o", str(module_dir / (source.stem + ".olean")),
             str(source)], env)
        if source.stem.endswith("Controls"):
            closures = re.findall(r"depends on axioms:\s*\[([^\]]*)\]", log.decode())
            assert len(closures) == 14
            for closure in closures:
                assert set(x.strip() for x in closure.split(",")) <= {
                    "propext", "Classical.choice", "Quot.sound"}
    run(version + "-local-kernel-replay", [checker, "--verbose", NAME, NAME + "Controls"], env)
    for mode, values in CONTROLS:
        arguments = " ".join(map(str, values))
        mutant = out / version / ("Mutant-" + mode + ".lean")
        mutant.write_text("import " + NAME + "Controls\n"
            "open Trust.Cert.CheckedMulI128Signed\n"
            "open Trust.Cert.CheckedMulI128Signed.Controls\n"
            "example : (if originalSourceSignedFlag " + arguments + " then (1 : BitVec 1) else 0) =\n"
            "    (if mutantFlag ." + mode + " " + arguments + " then (1 : BitVec 1) else 0) :=\n"
            "  original_signed_limb_check_flag " + arguments + "\n")
        run(version + "-hostile-proof-substitution-" + mode, [lean, str(mutant)], env, reject=True)

result = {
    "status": "PASS", "rows": rows, "tools": tool_rows, "imports": imports,
    "base": "56d6bc7885b750e8de7f2918692426669feb8794",
    "source_hashes": {p: sha(data) for p, data in before.items()},
    "source_unchanged": all((SOURCE / p).read_bytes() == data for p, data in before.items()),
    "unsigned_source_unchanged": sha((ROOT / "Trust/Cert/CheckedMulI128Unsigned.lean").read_bytes())
        == UNSIGNED["source_hashes"]["formal/lean/Trust/Cert/CheckedMulI128Unsigned.lean"],
    "rust_original_source_sha256": sha((SOURCE / "crates/trust-cg-verify/src/checked_mul_i128_proofs.rs").read_bytes()),
    "allowed_axioms": ["propext", "Classical.choice", "Quot.sound"],
    "scope": "Exact full-domain signed flag theorem under two genuine worlds; local reference-kernel replay, no independent Clean check, SMT/CIC binding or production grade change.",
}
assert result["source_unchanged"] and result["unsigned_source_unchanged"]
result["artifacts"] = [{"path": str(p.relative_to(out)), "sha256": sha(p.read_bytes()),
                        "size": p.stat().st_size}
                       for p in sorted(out.rglob("*")) if p.is_file()]
(out / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": result["status"], "rows": len(rows),
                  "result": str(out / "RESULT.json")}), flush=True)
