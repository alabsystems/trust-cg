/-
  Exact signed division-free i128 flag arithmetic. This theorem does not
  register a production verdict or replace original SMT/CIC correspondence.
-/
import Trust.Cert.CheckedMulI128Unsigned
import Std.Tactic.BVDecide

set_option autoImplicit false
namespace Trust.Cert.CheckedMulI128Signed
open Trust.Cert.CheckedMulI128Unsigned

def low64BV (x : BitVec 128) : BitVec 64 := x.truncate 64

def signNegative (x : BitVec 128) : Bool := decide (x.extractLsb' 127 1 = 1)

def signMask (x : BitVec 64) : BitVec 64 := x.sshiftRight 63

def boolMask (negative : Bool) : BitVec 64 := if negative then BitVec.allOnes 64 else 0

def maskedLow (lo mask : BitVec 64) : BitVec 64 := (lo ^^^ mask) - mask

def maskedHigh (lo hi mask : BitVec 64) : BitVec 64 :=
  (hi ^^^ mask) - mask - (((lo ||| (0 - lo)) >>> (63 : Nat)) &&& mask)

def magnitude (x : BitVec 128) : BitVec 128 := if signNegative x then -x else x

def resultNegative (a b : BitVec 128) : Bool := !(signNegative a == signNegative b)

def unsignedCore (al ah bl bh p1 : BitVec 64) : Prop :=
  let t := (limbProductBV ah bl).truncate 64 + (limbProductBV al bh).truncate 64
  high64BV (limbProductBV ah bl) ≠ 0 ∨
    high64BV (limbProductBV al bh) ≠ 0 ∨ p1 < t ∨ (ah ≠ 0 ∧ bh ≠ 0)

instance (al ah bl bh p1 : BitVec 64) : Decidable (unsignedCore al ah bl bh p1) := by
  unfold unsignedCore
  infer_instance

def originalSourceSignedFlag (al ah bl bh : BitVec 64) : Prop :=
  let a := join128BV al ah
  let b := join128BV bl bh
  let ua := magnitude a
  let ub := magnitude b
  let high := originalSourceBV (low64BV ua) (high64BV ua) (low64BV ub) (high64BV ub)
  let low := ua * ub
  let limit : BitVec 128 := if resultNegative a b then
    170141183460469231731687303715884105728 else 170141183460469231731687303715884105727
  high ≠ 0 ∨ limit < low

def originalMachineSignedFlag (al ah bl bh : BitVec 64) : Prop :=
  let a := join128BV al ah
  let b := join128BV bl bh
  let r := a * b
  let ma := signMask (high64BV a)
  let mb := signMask (high64BV b)
  let mn := ma ^^^ mb
  let ou := unsignedCore
    (maskedLow (low64BV a) ma) (maskedHigh (low64BV a) (high64BV a) ma)
    (maskedLow (low64BV b) mb) (maskedHigh (low64BV b) (high64BV b) mb)
    (maskedHigh (low64BV r) (high64BV r) mn)
  let bad := signMask (high64BV r) ^^^ mn ≠ 0 ∧
    low64BV r ||| high64BV r ≠ 0
  ou ∨ bad

instance (al ah bl bh : BitVec 64) : Decidable (originalSourceSignedFlag al ah bl bh) := by
  unfold originalSourceSignedFlag
  infer_instance

instance (al ah bl bh : BitVec 64) : Decidable (originalMachineSignedFlag al ah bl bh) := by
  unfold originalMachineSignedFlag
  infer_instance

theorem signMask_actual (x : BitVec 128) :
    signMask (high64BV x) = boolMask (signNegative x) := by
  unfold signMask high64BV boolMask signNegative
  bv_decide

theorem maskedLow_transport (x : BitVec 128) (negative : Bool) :
    maskedLow (low64BV x) (boolMask negative) =
      low64BV (if negative then -x else x) := by
  unfold maskedLow low64BV boolMask
  bv_decide

theorem maskedHigh_transport (x : BitVec 128) (negative : Bool) :
    maskedHigh (low64BV x) (high64BV x) (boolMask negative) =
      high64BV (if negative then -x else x) := by
  unfold maskedHigh low64BV high64BV boolMask
  bv_decide

theorem xor_sign_masks (a b : BitVec 128) :
    signMask (high64BV a) ^^^ signMask (high64BV b) = boolMask (resultNegative a b) := by
  rw [signMask_actual, signMask_actual]
  unfold resultNegative boolMask
  cases signNegative a <;> cases signNegative b <;> decide

theorem join_actual_limbs (x : BitVec 128) : join128BV (low64BV x) (high64BV x) = x := by
  unfold join128BV low64BV high64BV
  bv_decide

/-- This is a ring identity at the actual width, not a nonlinear solver premise. -/
theorem magnitude_product (a b : BitVec 128) :
    (if resultNegative a b then -(a * b) else a * b) = magnitude a * magnitude b := by
  unfold resultNegative magnitude
  cases signNegative a <;> cases signNegative b <;> simp

/-- Exact sign/zero reduction for an unrestricted full 128-bit product residue. -/
theorem signed_limit_reduction (p : BitVec 128) (negative : Bool) :
    ((if negative then (170141183460469231731687303715884105728 : BitVec 128)
      else 170141183460469231731687303715884105727) < p) ↔
      (signMask (high64BV (if negative then -p else p)) ^^^ boolMask negative ≠ 0 ∧
        low64BV (if negative then -p else p) |||
          high64BV (if negative then -p else p) ≠ 0) := by
  unfold signMask high64BV low64BV boolMask
  bv_decide

end Trust.Cert.CheckedMulI128Signed
