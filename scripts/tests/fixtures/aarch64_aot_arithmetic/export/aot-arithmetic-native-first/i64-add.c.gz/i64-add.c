#include <stdint.h>
#include <stdio.h>
extern int64_t calculate(int64_t, int64_t);
int main(void){
uint64_t values[]={0,1,2,4095,4096,UINT32_MAX,UINT64_C(1)<<31,UINT64_C(1)<<32,INT64_MAX,UINT64_C(1)<<63,UINT64_MAX-1,UINT64_MAX};
for(unsigned i=0;i<12;i++)for(unsigned j=0;j<12;j++){
uint64_t a=(uint64_t)values[i], b=(uint64_t)values[j];
uint64_t actual=(uint64_t)calculate((int64_t)a,(int64_t)b), expected=(uint64_t)(a+b);
if(actual!=expected)return 1;
}
puts("ARITHMETIC_AOT_NATIVE calls=144");return 0;
}
